/*
 * IJA (Seminář Java): 2025/26 Ukol 1
 * Author:  Radek Kočí, VUT FIT
 * Created: 02/2026
 */
package ija.homework1.scheme.blocks;

import java.util.Map;

/** 
 * Blok provádějící součet dvou vstupů. Vstupní porty jsou pojmenované "a" a "b".
 * Po provedení výpočtu ukládá do výstupního portu výsledek a + b.
 */
public class AddBlock extends Block {
    /**
     * Vytvoří instanci bloku pro sčítání.
     * @param name Název blok
     * @throws IllegalArgumentException pokud není zadán název bloku
     */
    public AddBlock(String name) { super(name, "a", "b"); }

    @Override
    protected double compute(Map<String, Double> inputs){
        return inputs.get("a") + inputs.get("b");
    }

}
